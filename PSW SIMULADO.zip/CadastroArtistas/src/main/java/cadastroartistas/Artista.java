
package cadastroartistas;

/**
 *
 * @author Macetim
 */
public class Artista {
    private String nomeArtistico;
    private String banda;
    private int anosDC;
    private String estiloMusical;
    private int index;

    public Artista(String nomeArtistico, String banda, int anosDC, String estiloMusical, int index) {
        this.nomeArtistico = nomeArtistico;
        this.banda = banda;
        this.anosDC = anosDC;
        this.estiloMusical = estiloMusical;
        this.index = index;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
     
    public String getNomeArtistico() {
        return nomeArtistico;
    }

    public void setNomeArtistico(String nomeArtistico) {
        this.nomeArtistico = nomeArtistico;
    }

    public String getBanda() {
        return banda;
    }

    public void setBanda(String banda) {
        this.banda = banda;
    }

   

    public int getAnosDC() {
        return anosDC;
    }

    public void setAnosDC(int anosDC) {
        this.anosDC = anosDC;
    }

    public String getEstiloMusical() {
        return estiloMusical;
    }

    public void setEstiloMusical(String estiloMusical) {
        this.estiloMusical = estiloMusical;
    }
    
    
}
