
package cadastroartistas;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Macetim
 */
@WebServlet(name = "validaServlet", urlPatterns = {"/validaServlet"})
public class validaServlet extends HttpServlet  {
    public static ArrayList<Artista> listaART = new ArrayList<Artista>();
    int i =0;
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
       req.setCharacterEncoding("UTF-8");
       resp.setCharacterEncoding("UTF-8");
       String nomeArtistico = (String) req.getParameter("nomeArtistico");
       String banda = (String) req.getParameter("banda");
       String anosDC = (String) req.getParameter("anosDC");
       String estiloMusical = (String) req.getParameter("estiloMusical");
       
       boolean formValido = true;
       if(nomeArtistico == null || nomeArtistico.equals("") || nomeArtistico.length()>30){
            req.setAttribute("msgerroNomeA", "O nome deve ser preenchido e ter menos de 30 caracteres");
            formValido = false;
        }
       if( banda.length()>40){
            req.setAttribute("msgerroBanda", "A Banda deve ter até 40 caracteres");
            formValido = false;
        }
       try{
       if(anosDC == null || anosDC.equals("") || Integer.valueOf(anosDC)>99){
            req.setAttribute("msgerroAnos", "Os anos de carreira precisam estar preenchidos e não podem ser maiores que 99(velhão vc eih)");
            formValido = false;
        }}catch(Exception e){
            req.setAttribute("msgerroAnos", "Os anos de carreira só podem ser numeros seu manezão");
            formValido = false;
        }
       if(formValido){
            Artista a = new Artista(nomeArtistico, banda, Integer.valueOf(anosDC), estiloMusical,i);
            listaART.add(a);
            i++;
            req.getServletContext().setAttribute("Artistas",listaART);
            req.getRequestDispatcher("tabela.jsp").forward(req, resp);
       }
       else{
            req.getRequestDispatcher("index.jsp").forward(req, resp);
       }
        
    }

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        
    }

}
