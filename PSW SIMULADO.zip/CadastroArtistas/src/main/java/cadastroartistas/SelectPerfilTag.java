/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastroartistas;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 *
 * @author Diogo
 */
public class SelectPerfilTag extends SimpleTagSupport {

    private String estiloMusical;

    @Override
    public void doTag() throws JspException, IOException {
        String selectHtml
                = "<select align='center' name='estiloMusical' class='form-control col-sm-4' w-100' id='estiloMusical' required>"
                + "    <option value='ROCK'" + ("ROCK".equals(estiloMusical) ? "selected" : "") + " >ROCK</option>"
                + "    <option value='POP' " + ("POP".equals(estiloMusical) ? "selected" : "") + " >POP</option>"
                + "    <option value='OUTROS' " + ("OUTROS".equals(estiloMusical) ? "selected" : "") + " >OUTROS</option>"
                + "</select>";

        getJspContext().getOut().print(selectHtml);
    }

    public String getEstiloMusical() {
        return estiloMusical;
    }

    public void setEstiloMusical(String estiloMusical) {
        this.estiloMusical = estiloMusical;
    }

}
